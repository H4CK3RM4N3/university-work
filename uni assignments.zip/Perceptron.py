#studentID:201348605
import numpy as np

#imports training data and adjusts it into usable array form
filename = 'train.data'
with open(filename) as file:
    train = np.array([[float(i) for i in ((line.rstrip()).replace('class-','')).split(',')] for line in file])
#imports test data and adjusts it into usable array form 
filename = 'test.data'
with open(filename) as file:
    test = np.array([[float(i) for i in ((line.rstrip()).replace('class-','')).split(',')] for line in file])


#Task 2

# Make a prediction with weights (Forward calculation)
def predict(row, weights):
    activation = weights[0]
    for i in range(len(row)-1):
        activation += weights[i + 1] * row[i]
    return 1.0 if activation >= 0.0 else 0.0

#adjusts training weights
def train_weights(train, l_rate, n_epoch):
    weights = np.zeros((len(train[0]))) # initialising with 0
    #weights = np.random.rand(5) # initialising with random numbers
    for epoch in range(n_epoch):
        sum_error = 0.0
        for row in train:
            prediction = predict(row, weights)
            error = row[-1] - prediction
            sum_error += abs(error)
            weights[0] = weights[0] + l_rate * error # bias
            for i in range(len(row)-1):
                weights[i + 1] = weights[i + 1] + l_rate * error * row[i]
        print('>> epoch=%d, lrate=%.3f, error=%.3f' % (epoch, l_rate, sum_error))
    return weights

#shows how accurate the perceptron is
def accuracy_metric(actual, predicted):
    correct = 0
    for i in range(len(actual)):
        if actual[i] == predicted[i]:
            correct += 1
    return correct / float(len(actual)) * 100.0

def show_accuracy(data, weights):
    predicted = []
    for row in data:
        prediction = predict(row, weights)
        predicted.append(prediction)
        #print("Expected=%d, Predicted=%d" % (row[-1], prediction))

    return accuracy_metric(data[:,4], predicted)


    

#Task 3   
def One_Vs_One(Class_N, Class_M):  
    train1 = np.copy(train)
    train1 = train1[(train1[:,4] == Class_N) | (train1[:,4] == Class_M) ]
    train1[:,4] = train1[:,4] > Class_N
    test1 = np.copy(test)
    test1 = test1[(test1[:,4] == Class_N) | (test1[:,4] == Class_M) ]
    test1[:,4] = test1[:,4] > Class_N
    l_rate = 0.1
    n_epoch = 20
    weights = train_weights(train1, l_rate, n_epoch)
    print('\nNew weights: ', weights)
    print('Train data accuracy: ', show_accuracy(train1, weights))
    print('Test data accuracy: ', show_accuracy(test1, weights))
    
#Task 4
def One_vs_Rest(Class_num):
    train_1_v_r = np.copy(train)
    train_1_v_r[:,4] = ~(train_1_v_r [:,4] != Class_num)
    test_1_v_r = np.copy(test)
    test_1_v_r[:,4] = ~(test_1_v_r [:,4] != Class_num)
    l_rate = 0.1
    n_epoch = 20
    weights = train_weights(train_1_v_r, l_rate, n_epoch)
    print('\nNew weights: ', weights)
    print('Train data accuracy: ', show_accuracy(train_1_v_r, weights))
    print('Test data accuracy: ', show_accuracy(test_1_v_r, weights))



#Task 5
# Estimate Perceptron weights using stochastic gradient descent
def train_weights_regularised(train, l_rate, n_epoch, L2):
     weights = np.zeros((len(train[0])))
     for epoch in range(n_epoch):
        sum_error = 0.0
        for row in train:
            prediction = predict(row, weights)
            error = row[-1] - prediction #
            sum_error += abs(error)
            weights[0] -= L2 * weights[0]
            weights[0] = weights[0]  + l_rate * error # bias
            for i in range(len(row)-1):
                weights[i + 1] -= L2 * weights[i + 1]
                weights[i + 1] = weights[i + 1]  + l_rate * error * row[i]
        #print('>> epoch=%d, lrate=%.3f, error=%.3f' % (epoch, l_rate, sum_error))
     return weights


#regularisation

def L2regularisation(Class_num):
    reg_L2 = [0, 0.01, 0.1, 1.0, 10.0, 100.0]
    for L in reg_L2:
        print('\nlamda: ', L)
        train_1_v_r = np.copy(train)
        train_1_v_r[:,4] = ~(train_1_v_r [:,4] != Class_num)
        test_1_v_r = np.copy(test)
        test_1_v_r[:,4] = ~(test_1_v_r [:,4] != Class_num)
        l_rate = 0.1
        n_epoch = 20
        weights = train_weights_regularised(train_1_v_r, l_rate, n_epoch, L)
        print('\nNew weights: ', weights)
        print('Train data accuracy: ', show_accuracy(train_1_v_r, weights))
        print('Test data accuracy: ', show_accuracy(test_1_v_r, weights))